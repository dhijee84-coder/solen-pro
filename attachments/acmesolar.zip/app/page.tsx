'use client'

import { useState } from 'react'

const navItems = [
  { label: 'About Us', links: ['Overview', 'Our Journey', 'Board of Directors', 'Leadership', 'Awards & Certifications'] },
  { label: 'Our Business', links: ['Overview', 'Portfolio'] },
  { label: 'Investors', links: ['Overview', 'Financials', 'Shareholders Information', 'Policies', 'IPO Documents'] },
  { label: 'Sustainability', links: ['Overview', 'ESG', 'HSE', 'CSR', 'Sustainability Policies'] },
  { label: 'Careers', links: ['Overview', 'Join Us'] },
]

const slides = [
  { title: <>A Project That Leads<br />Our Green Vision</>, body: <>Setting new benchmarks in renewable power with our <b>1200 MW ISTS</b><br />project — a defining example of precision-engineered solar energy.</>, image: 'https://www.acmesolar.in/media/images/ACMES-Banner.jpg', action: 'Explore more' },
  { title: <>Driving the Future of<br />Clean Energy in India</>, body: <>Powering a sustainable future with <b>~7.4 GW</b> of clean, renewable energy.</>, image: 'https://www.acmesolar.in/media/images/ACME_Q1-FY27-Results-Highlights-Website-Banner.jpg', action: 'Know more' },
  { title: <>Shaping a Carbon<br />Neutral Future</>, body: <>Spanning <b>11 states</b>, we are dedicated to championing a sustainable energy future.</>, image: 'https://www.acmesolar.in/media/images_webp/solar-panels-with-wind-turbines%204.webp', action: 'Explore more' },
]

const solutions = [
  ['Solar', 'Our 3140 MW of solar power projects deliver clean & affordable energy.', 'https://www.acmesolar.in/media/images_webp/solar2-resized.webp'],
  ['Hybrid / FDRE', 'Our 3480 MW combined solar, wind and battery capacity ensures stable, uninterrupted power generation.', 'https://www.acmesolar.in/media/images_webp/Solar-Wind-Hybrid-resized.webp'],
  ['Wind', 'Our 150 MW wind capacity delivers reliable energy.', 'https://www.acmesolar.in/media/images_webp/wind-img-resized.webp'],
]

export default function Page() {
  const [slide, setSlide] = useState(0)
  const [open, setOpen] = useState<string | null>(null)
  const [cookies, setCookies] = useState(true)
  const current = slides[slide]

  return <main>
    <header className="site-header">
      <a className="brand" href="#top" aria-label="Acme Solar home"><img src="https://www.acmesolar.in/media/images/ACME-Logo-SVG.svg" alt="Acme Solar logo" /></a>
      <nav aria-label="Main navigation">
        {navItems.map(item => <div className="nav-item" key={item.label} onMouseEnter={() => setOpen(item.label)} onMouseLeave={() => setOpen(null)}>
          <button onClick={() => setOpen(open === item.label ? null : item.label)}>{item.label}</button>
          {open === item.label && <div className="dropdown">{item.links.map(link => <a href="#" key={link}>{link}</a>)}</div>}
        </div>)}
        <a href="#media">Media</a><a href="#contact">Contact Us</a>
      </nav>
      <button className="menu-button" aria-label="Open menu">☰</button>
    </header>

    <section id="top" className="hero" style={{ backgroundImage: `linear-gradient(90deg, rgba(5,26,58,.72), rgba(5,26,58,.08)), url('${current.image}')` }}>
      <button className="hero-arrow left" onClick={() => setSlide((slide + slides.length - 1) % slides.length)} aria-label="Previous slide">‹</button>
      <div className="hero-copy"><p className="eyebrow">ACME SOLAR HOLDINGS LIMITED</p><h1>{current.title}</h1><p>{current.body}</p><a className="pill-button" href="#business">{current.action}</a></div>
      <button className="hero-arrow right" onClick={() => setSlide((slide + 1) % slides.length)} aria-label="Next slide">›</button>
      <div className="dots">{slides.map((_, i) => <button key={i} className={i === slide ? 'active' : ''} onClick={() => setSlide(i)} aria-label={`Go to slide ${i + 1}`} />)}</div>
    </section>

    <section className="intro section"><div className="intro-image"><img src="https://www.acmesolar.in/media/compressed-images/ACME-Solar-Holdings_new.png" alt="Solar panels at an ACME facility" /></div><div><p className="eyebrow blue">WHO WE ARE</p><h2>ACME Solar Holdings Limited</h2><p>ACME Solar is one of India’s leading renewable energy independent power producers (IPP), managing a 7.39 GW portfolio across solar, wind, hybrid, and FDRE projects. We develop, build, own, and operate large-scale clean energy solutions.</p><p>Founded in 2003, ACME entered the renewable energy sector in 2009 and commissioned its first solar plant in 2012. Today we continue to lead innovation and sustainability in the renewable energy sector.</p><a className="text-link" href="#business">Know more →</a></div></section>

    <section id="business" className="portfolio section"><div className="portfolio-copy"><p className="eyebrow blue">OUR PORTFOLIO</p><h2>Powering a cleaner tomorrow</h2><p>Our diverse portfolio spans solar, wind, hybrid, and FDRE solutions, driving India's transition to sustainable energy.</p><div className="metrics"><div><strong>7,390 MW</strong><span>Contracted</span></div><div><strong>2,918 MW</strong><span>Operational</span></div><div><strong>4,472 MW</strong><span>Under construction</span></div></div></div><img src="https://www.acmesolar.in/media/images_webp/solar-panels-with-wind-turbines%204.webp" alt="Solar panels and wind turbines" /></section>

    <section className="solutions section"><div className="section-heading"><p className="eyebrow blue">WHAT WE DO</p><h2>Our Renewable Solutions</h2></div><div className="solution-grid">{solutions.map(([name, text, image]) => <article className="solution-card" key={name}><img src={image} alt={`${name} energy solution`} /><div><h3>{name}</h3><p>{text}</p><a href="#contact">Learn more →</a></div></article>)}</div></section>

    <section className="impact section"><div className="section-heading"><p className="eyebrow blue">OUR IMPACT</p><h2>Join the Renewable Energy Revolution</h2></div><div className="impact-grid">{[['Top 10','Renewable energy players in India'],['7.39 GW','Total capacity across solar, wind, FDRE and hybrid systems'],['20,000+','Acres of solar installations'],['2.9M','Tonnes of CO₂ emissions reduced in FY25'],['99%+','Plant availability']].map(([value, label]) => <div className="impact-stat" key={value}><strong>{value}</strong><p>{label}</p></div>)}</div></section>

    <section id="contact" className="cta section"><p className="eyebrow">GET IN TOUCH</p><h2>We are here to hear!</h2><a className="pill-button" href="mailto:info@acmesolar.in">Reach out us</a></section>

    <footer id="media"><div className="footer-inner"><div className="footer-brand"><img src="https://www.acmesolar.in/media/images/ACME-Logo-SVG.svg" alt="ACME Solar" /><p>Leading through innovation.</p></div><div className="footer-links">{['About Us','Our Business','Investors','Sustainability','Careers','Media','Contact Us'].map(label => <a href="#top" key={label}>{label}</a>)}</div></div><p className="copyright">© ACME Solar 2026&nbsp; | &nbsp;All Rights Reserved</p></footer>

    {cookies && <div className="cookie"><p>This website uses cookies or similar technologies to enhance your browsing experience.</p><p>By continuing to use our website, you agree to our privacy policy.</p><div><button onClick={() => setCookies(false)}>Accept</button><button onClick={() => setCookies(false)}>Decline</button></div></div>}
  </main>
}
