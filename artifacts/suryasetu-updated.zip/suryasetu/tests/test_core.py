import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from fastapi.testclient import TestClient

os.environ["DATABASE_URL"] = "sqlite:///./test_suryasetu.db"

from app.main import app
from app.database import Base, engine, SessionLocal
from app import models
from app.security import hash_password
from app.services import allocation_service


@pytest.fixture(autouse=True)
def fresh_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(app)


def make_staff(db, role, username):
    u = models.User(role=role, full_name=username, username=username, hashed_password=hash_password("pw123456"))
    db.add(u)
    db.commit()
    db.refresh(u)
    return u


def make_project_with_panels(db, code="TST-001", count=4):
    p = models.Project(project_code=code, project_name="Test Project", status=models.ProjectStatus.ACTIVE, total_panels=count)
    db.add(p)
    db.flush()
    for i in range(count):
        db.add(models.Panel(serial_number=f"{code}-P{i+1:03d}", project_id=p.id, added_sequence=i + 1,
                             status=models.PanelStatus.AVAILABLE, watt_rating=400))
    db.commit()
    db.refresh(p)
    return p


# ── Auth ──

def test_client_otp_registration_and_login(client):
    r = client.post("/api/auth/otp/send", json={"phone": "9845000001"})
    assert r.status_code == 200
    code = r.json()["dev_otp"]

    r2 = client.post("/api/auth/otp/verify", json={"phone": "9845000001", "code": code, "full_name": "Test User"})
    assert r2.status_code == 200
    assert r2.json()["is_new_client"] is True

    r3 = client.get("/api/client/me")
    assert r3.status_code == 200
    assert r3.json()["user"]["name"] == "Test User"


def test_invalid_otp_rejected(client):
    client.post("/api/auth/otp/send", json={"phone": "9845000002"})
    r = client.post("/api/auth/otp/verify", json={"phone": "9845000002", "code": "0000"})
    assert r.status_code == 400


def test_admin_login_and_client_cannot_access_admin_api(client):
    db = SessionLocal()
    make_staff(db, models.RoleName.ADMIN, "testadmin")
    db.close()

    r = client.post("/api/auth/admin/login", json={"username": "testadmin", "password": "pw123456"})
    assert r.status_code == 200

    r2 = client.post("/api/auth/otp/send", json={"phone": "9845000003"})
    code = r2.json()["dev_otp"]
    client2 = TestClient(app)
    client2.post("/api/auth/otp/verify", json={"phone": "9845000003", "code": code})
    r3 = client2.get("/api/admin/dashboard")
    assert r3.status_code == 403


# ── FIFO allocation ──

def test_fifo_allocation_order():
    db = SessionLocal()
    project = make_project_with_panels(db, "FIFO-1", 4)
    user = models.User(role=models.RoleName.CLIENT, full_name="C1", phone="9000000001")
    db.add(user)
    db.flush()
    profile = models.ClientProfile(user_id=user.id)
    db.add(profile)
    db.commit()

    admin = make_staff(db, models.RoleName.ADMIN, "fifo-admin")

    panels = allocation_service.allocate_panels(db, project.id, profile.id, 2, admin)
    assert [p.serial_number for p in panels] == ["FIFO-1-P001", "FIFO-1-P002"]

    user2 = models.User(role=models.RoleName.CLIENT, full_name="C2", phone="9000000002")
    db.add(user2)
    db.flush()
    profile2 = models.ClientProfile(user_id=user2.id)
    db.add(profile2)
    db.commit()

    panels2 = allocation_service.allocate_panels(db, project.id, profile2.id, 1, admin)
    assert [p.serial_number for p in panels2] == ["FIFO-1-P003"]
    db.close()


def test_capacity_full_rejects_further_allocation():
    db = SessionLocal()
    project = make_project_with_panels(db, "CAP-1", 2)
    user = models.User(role=models.RoleName.CLIENT, full_name="C1", phone="9000000003")
    db.add(user)
    db.flush()
    profile = models.ClientProfile(user_id=user.id)
    db.add(profile)
    db.commit()
    admin = make_staff(db, models.RoleName.ADMIN, "cap-admin")

    allocation_service.allocate_panels(db, project.id, profile.id, 2, admin)
    db.refresh(project)
    assert project.status == models.ProjectStatus.FULL

    user2 = models.User(role=models.RoleName.CLIENT, full_name="C2", phone="9000000004")
    db.add(user2)
    db.flush()
    profile2 = models.ClientProfile(user_id=user2.id)
    db.add(profile2)
    db.commit()

    with pytest.raises(allocation_service.AllocationError):
        allocation_service.allocate_panels(db, project.id, profile2.id, 1, admin)
    db.close()


def test_insufficient_panels_rejected():
    db = SessionLocal()
    project = make_project_with_panels(db, "INS-1", 1)
    user = models.User(role=models.RoleName.CLIENT, full_name="C1", phone="9000000005")
    db.add(user)
    db.flush()
    profile = models.ClientProfile(user_id=user.id)
    db.add(profile)
    db.commit()
    admin = make_staff(db, models.RoleName.ADMIN, "ins-admin")

    with pytest.raises(allocation_service.AllocationError):
        allocation_service.allocate_panels(db, project.id, profile.id, 5, admin)
    db.close()


# ── permissions ──

def test_admin_cannot_manage_super_admin(client):
    db = SessionLocal()
    make_staff(db, models.RoleName.ADMIN, "regularadmin")
    db.close()
    client.post("/api/auth/admin/login", json={"username": "regularadmin", "password": "pw123456"})
    r = client.post("/api/admin/staff", json={"full_name": "X", "username": "newsuper", "password": "pw123456", "role": "SUPER_ADMIN"})
    assert r.status_code == 403
