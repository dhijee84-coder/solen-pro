/* Shared helpers used across every SuryaSetu page. */

async function api(path, opts = {}) {
  const res = await fetch(path, {
    method: opts.method || "GET",
    headers: opts.body ? { "Content-Type": "application/json" } : {},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: "same-origin",
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) {
    const msg = (data && data.detail) ? data.detail : `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

async function apiUpload(path, formData) {
  const res = await fetch(path, { method: "POST", body: formData, credentials: "same-origin" });
  let data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error((data && data.detail) || "Upload failed");
  return data;
}

const inr = (n) => "₹" + Math.round(n || 0).toLocaleString("en-IN");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const ico = (n, sz = 16) => `<svg class="ico" style="width:${sz}px;height:${sz}px" viewBox="0 0 24 24"><use href="#i-${n}"/></svg>`;
const fDate = (iso) => iso ? new Date(iso).toLocaleDateString("en-IN", {day:"2-digit", month:"short", year:"numeric"}) : "—";
const fDateTime = (iso) => iso ? new Date(iso).toLocaleString("en-IN", {day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit", hour12:true}) : "—";

function toast(msg, isError) {
  let box = document.getElementById("toast-box");
  if (!box) {
    box = document.createElement("div");
    box.id = "toast-box";
    box.style.cssText = "position:fixed;bottom:20px;right:20px;z-index:999;display:flex;flex-direction:column;gap:8px";
    document.body.appendChild(box);
  }
  const t = document.createElement("div");
  t.className = "card pad rise";
  t.style.cssText = `max-width:320px;font-size:13.5px;border-color:${isError ? "var(--alert)" : "var(--export)"}`;
  t.textContent = msg;
  box.appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

async function logout() {
  try { await api("/api/auth/logout", { method: "POST" }); } catch (e) {}
  window.location.href = "/login";
}
