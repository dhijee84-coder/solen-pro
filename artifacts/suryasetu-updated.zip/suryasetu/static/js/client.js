let STATE = { tab: "kyc", overview: null, gen: null, bill_draft: null, reading: false };

async function boot() {
  try {
    STATE.overview = await api("/api/client/me");
  } catch (e) {
    window.location.href = "/login";
    return;
  }
  document.getElementById("hdr-name").textContent = STATE.overview.user.name;
  document.getElementById("hdr-phone").textContent = "+91 " + (STATE.overview.user.phone || "");
  const ec = STATE.overview.electricity;
  if (ec && ec.rr_number) {
    const badge = document.getElementById("hdr-rr");
    badge.style.display = "inline";
    badge.textContent = `RR ${ec.rr_number} · ${ec.proposed_kw} kW`;
  }
  render();
}

function kycDone() { return STATE.overview.profile.kyc_status === "VERIFIED"; }
function panDone() { return !!STATE.overview.profile.pan_number; }

function navItems() {
  return [
    {id: "kyc", label: "Verification", icon: "shield", lock: false},
    {id: "bill", label: "Connection & sizing", icon: "file", lock: !panDone()},
    {id: "project", label: "Project stages", icon: "activity", lock: !kycDone()},
    {id: "money", label: "Payments & history", icon: "wallet", lock: !kycDone()},
    {id: "gen", label: "Power generation", icon: "trend", lock: !kycDone()},
    {id: "services", label: "Services & support", icon: "settings", lock: !kycDone()},
  ];
}

function gotoTab(id) {
  STATE.tab = id;
  render();
  window.scrollTo(0, 0);
}

function render() {
  const due = (STATE.overview.stages || []).find(s => s.status === "COMPLETED" && s.payment_status !== "PAID");
  const paymentDueStage = (STATE.overview.stages || []).find(s => s.payment_status === "DUE");
  document.getElementById("hdr-alert").style.display = paymentDueStage ? "inline-flex" : "none";

  const nav = navItems();
  document.getElementById("rail-nav").innerHTML = nav.map(n => `
    <button class="rail-btn ${STATE.tab === n.id ? "on" : ""}" ${n.lock ? "disabled" : ""} onclick="gotoTab('${n.id}')">
      ${ico(n.lock ? "lock" : n.icon, 15)}<span style="flex:1">${n.label}</span>
    </button>`).join("");

  const p = STATE.overview.profile;
  document.getElementById("rail-onboarding").innerHTML = [
    ["PAN verified", panDone()],
    ["Aadhaar verified", kycDone()],
    ["Bill uploaded", !!(STATE.overview.electricity && STATE.overview.electricity.rr_number)],
  ].map(([t, v]) => `<div style="display:flex;align-items:center;gap:9px;padding:6px 12px;font-size:12.5px;color:${v ? "var(--export)" : "var(--mute)"}">
      ${ico(v ? "check" : "clock", 13)} ${t}</div>`).join("");

  const views = { kyc: viewKyc, bill: viewBill, project: viewProject, money: viewMoney, gen: viewGen, services: viewServices };
  document.getElementById("main").innerHTML = (views[STATE.tab] || viewKyc)();
  wireTabExtras();
}

/* ── KYC ── */
function viewKyc() {
  const p = STATE.overview.profile;
  return `<div class="rise" style="max-width:780px">
    <div class="eyebrow">Step 1 of 3</div>
    <h2 class="disp" style="font-size:27px;font-weight:600;margin:8px 0">Verify your identity</h2>
    <p style="color:var(--mute);font-size:14px;max-width:560px;margin-top:0">
      PAN and Aadhaar go on the net-metering agreement and the subsidy claim. Each is confirmed by OTP.</p>

    <div class="card pad" style="margin-top:22px">
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
        <div><div style="display:flex;align-items:center;gap:9px;color:var(--silver)">${ico("card",16)}
          <span class="disp" style="font-weight:600;font-size:16px;color:var(--ink)">PAN card</span></div>
          <p style="color:var(--mute);font-size:13px;margin:8px 0 0">Ten characters, exactly as printed on the card.</p></div>
        <span class="pill ${p.pan_number ? "p-done" : "p-due"}">${p.pan_number ? "Verified" : "Pending"}</span>
      </div>
      ${p.pan_number ? `<div class="mono" style="margin-top:16px;font-size:13px">${esc(p.pan_number)}</div>` : `
      <div style="display:flex;gap:12px;margin-top:16px;flex-wrap:wrap;align-items:flex-end">
        <div style="flex:1 1 240px">
          <label class="lab" for="f-pan">PAN number</label>
          <input id="f-pan" class="field mono" maxlength="10" placeholder="ABCDE1234F" style="letter-spacing:.14em;text-transform:uppercase">
        </div>
        <button class="btn flux" onclick="submitPan()">Verify</button>
      </div>
      <div class="err" id="pan-err"></div>`}
    </div>

    <div class="card pad" style="margin-top:14px;${panDone() ? "" : "opacity:.55;pointer-events:none"}">
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
        <div><div style="display:flex;align-items:center;gap:9px;color:var(--silver)">${ico("shield",16)}
          <span class="disp" style="font-weight:600;font-size:16px;color:var(--ink)">Aadhaar card</span></div>
          <p style="color:var(--mute);font-size:13px;margin:8px 0 0">${panDone() ? "Twelve digits." : "Unlocks once PAN is verified."}</p></div>
        <span class="pill ${p.aadhaar_masked ? "p-done" : panDone() ? "p-due" : "p-lock"}">${p.aadhaar_masked ? "Verified" : panDone() ? "Pending" : "Locked"}</span>
      </div>
      ${p.aadhaar_masked ? `<div class="mono" style="margin-top:16px;font-size:13px">${esc(p.aadhaar_masked)}</div>` : `
      <div style="display:flex;gap:12px;margin-top:16px;flex-wrap:wrap;align-items:flex-end">
        <div style="flex:1 1 240px">
          <label class="lab" for="f-aad">Aadhaar number</label>
          <input id="f-aad" class="field mono" maxlength="12" inputmode="numeric" placeholder="1234 5678 9012" style="letter-spacing:.14em">
        </div>
        <button class="btn flux" onclick="submitAadhaar()">Verify</button>
      </div>
      <div class="err" id="aad-err"></div>`}
    </div>
  </div>`;
}

async function submitPan() {
  const v = document.getElementById("f-pan").value;
  try {
    await api("/api/client/kyc/pan", { method: "POST", body: { pan_number: v } });
    STATE.overview = await api("/api/client/me");
    toast("PAN verified.");
    render();
  } catch (e) { document.getElementById("pan-err").textContent = e.message; }
}
async function submitAadhaar() {
  const v = document.getElementById("f-aad").value;
  try {
    await api("/api/client/kyc/aadhaar", { method: "POST", body: { aadhaar_number: v } });
    STATE.overview = await api("/api/client/me");
    toast("Aadhaar verified.");
    render();
  } catch (e) { document.getElementById("aad-err").textContent = e.message; }
}

/* ── Bill / sizing ── */
function viewBill() {
  const ec = STATE.overview.electricity;
  if (ec && ec.rr_number) {
    return `<div class="rise" style="max-width:780px">
      <div class="eyebrow">Connection on file</div>
      <h2 class="disp" style="font-size:27px;font-weight:600;margin:8px 0">Your electricity connection</h2>
      <div class="card pad grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-top:18px">
        ${kv("RR number", ec.rr_number)} ${kv("DISCOM", ec.discom)} ${kv("Tariff", ec.tariff)}
        ${kv("Sanctioned load", ec.sanctioned_load_kw + " kW")} ${kv("Avg. monthly units", ec.avg_monthly_units)}
        ${kv("Avg. monthly bill", inr(ec.avg_monthly_bill))} ${kv("Phase", ec.phase)}
      </div>
      <div class="card pad" style="margin-top:14px">
        <div class="disp" style="font-weight:600;font-size:16px;margin-bottom:10px">Proposed plant</div>
        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">
          ${kv("Capacity", ec.proposed_kw + " kW")} ${kv("System cost", inr(ec.system_cost))}
          ${kv("Subsidy estimate", inr(ec.subsidy_estimate))} ${kv("Payable", inr(ec.payable_amount))}
        </div>
      </div>
    </div>`;
  }
  if (STATE.reading) {
    return `<div class="rise" style="max-width:600px;text-align:center;padding-top:80px">
      ${ico("refresh", 22)} <span class="spin" style="display:inline-block"></span>
      <p style="color:var(--mute);margin-top:14px">Reading your electricity bill…</p></div>`;
  }
  if (STATE.bill_draft) {
    const d = STATE.bill_draft;
    return `<div class="rise" style="max-width:700px">
      <h2 class="disp" style="font-size:24px;font-weight:600;margin:8px 0">Review before saving</h2>
      <div class="card pad grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">
        ${kv("RR number", d.rr_number)} ${kv("DISCOM", d.discom)} ${kv("Tariff", d.tariff)}
        ${kv("Sanctioned load", d.sanctioned_load_kw + " kW")} ${kv("Avg. units/month", d.avg_monthly_units)}
        ${kv("Avg. bill/month", inr(d.avg_monthly_bill))}
      </div>
      <div class="card pad" style="margin-top:14px">
        <div class="disp" style="font-weight:600">Proposed ${d.proposed_kw} kW plant</div>
        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));margin-top:10px">
          ${kv("System cost", inr(d.system_cost))} ${kv("Subsidy est.", inr(d.subsidy_estimate))} ${kv("You pay", inr(d.payable_amount))}
        </div>
      </div>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button class="btn flux" onclick="saveBill()">Confirm & save</button>
        <button class="btn" onclick="STATE.bill_draft=null;render()">Start over</button>
      </div>
    </div>`;
  }
  return `<div class="rise" style="max-width:600px">
    <div class="eyebrow">Step 2 of 3</div>
    <h2 class="disp" style="font-size:27px;font-weight:600;margin:8px 0">Upload your electricity bill</h2>
    <p style="color:var(--mute);font-size:14px">We'll read your latest bill and propose a plant size.</p>
    <div class="drop" style="border:1px dashed var(--edge2);border-radius:4px;padding:30px 20px;text-align:center;background:rgba(18,41,67,.4);cursor:pointer" onclick="readBillSample()">
      ${ico("file", 22)}<p style="margin:10px 0 0;color:var(--mute)">Click to use a sample bill for this demo</p>
    </div>
  </div>`;
}

function kv(label, val) {
  return `<div><div class="eyebrow">${esc(label)}</div><div class="mono" style="font-size:14px;margin-top:4px">${esc(val)}</div></div>`;
}

async function readBillSample() {
  STATE.reading = true; render();
  const units = 240 + Math.round(Math.random() * 400);
  setTimeout(async () => {
    STATE.reading = false;
    STATE.bill_draft = await api("/api/client/bill/draft", { method: "POST", body: {
      rr_number: "BNG-" + Math.floor(1000000 + Math.random() * 8999999),
      discom: "BESCOM", division: "South, Jayanagar sub-division",
      service_address: "No. 42, 3rd Cross, Jayanagar 4th Block, Bengaluru 560011",
      tariff: "LT-2(a) Domestic", avg_monthly_units: units,
    }});
    render();
  }, 1200);
}

async function saveBill() {
  await api("/api/client/bill/save", { method: "POST", body: STATE.bill_draft });
  STATE.bill_draft = null;
  STATE.overview = await api("/api/client/me");
  toast("Electricity bill recorded.");
  render();
}

/* ── Project stages (busbar) ── */
function viewProject() {
  const stages = STATE.overview.stages || [];
  if (!stages.length) {
    return `<div class="rise" style="max-width:600px"><p style="color:var(--mute)">
      Your project will appear here once an administrator allocates panel capacity to your account.</p></div>`;
  }
  const rows = stages.map((s, i) => {
    const flow = s.status === "COMPLETED";
    const nodeClass = s.status === "COMPLETED" ? "done" : s.status === "IN_PROGRESS" ? "live" : s.payment_status === "DUE" ? "due" : "";
    const pillClass = s.status === "COMPLETED" ? "p-done" : s.status === "IN_PROGRESS" ? "p-live" : s.payment_status === "DUE" ? "p-due" : "p-lock";
    return `<div class="bus-row">
      <div class="bus-gut ${flow ? "flow" : ""}"><div class="bus-node ${nodeClass}">${s.stage_number}</div></div>
      <div class="stage">
        <div class="stage-hd">
          <div>
            <div class="disp" style="font-weight:600;font-size:15.5px">${esc(s.stage_name)}</div>
            <div style="color:var(--mute);font-size:13px;margin-top:3px">${s.percentage}% of contract value</div>
          </div>
          <span class="pill ${pillClass}">${s.status.replace(/_/g," ")}</span>
        </div>
        ${s.payment_status === "DUE" ? `<button class="btn flux sm" style="margin-top:10px" onclick="openPay('${s.id}', ${STATE.overview.project ? STATE.overview.project.contract_total * s.percentage / 100 : 0})">Pay for this stage</button>` : ""}
        ${s.completed_at ? `<div style="color:var(--mute);font-size:12px;margin-top:8px">Completed ${fDate(s.completed_at)}</div>` : ""}
      </div>
    </div>`;
  }).join("");
  return `<div class="rise" style="max-width:760px">
    <div class="eyebrow">Step 3 of 3</div>
    <h2 class="disp" style="font-size:27px;font-weight:600;margin:8px 0">Project stages</h2>
    <p style="color:var(--mute);font-size:14px">${STATE.overview.project ? esc(STATE.overview.project.project_name) : ""}</p>
    <div style="margin-top:10px">${rows}</div>
  </div>
  <div id="pay-modal"></div>`;
}

function openPay(stageId, amount) {
  document.getElementById("pay-modal").innerHTML = `
    <div class="modal-scrim" onclick="if(event.target===this) this.parentElement.innerHTML=''">
      <div class="sheet rise">
        <div class="sheet-hd"><div class="disp" style="font-weight:600">Pay ${inr(amount)}</div>
          <button class="btn sm bare" onclick="document.getElementById('pay-modal').innerHTML=''">✕</button></div>
        <div class="sheet-body">
          <label class="lab">Payment method</label>
          <div class="seg" style="margin-bottom:16px">
            <button class="on" id="pm-upi" onclick="setPm('upi')">UPI</button>
            <button id="pm-card" onclick="setPm('card')">Card</button>
            <button id="pm-nb" onclick="setPm('netbanking')">Net banking</button>
          </div>
          <button class="btn flux wide" onclick="settlePay('${stageId}', ${amount})">Pay ${inr(amount)}</button>
        </div>
      </div>
    </div>`;
}
let PM = "upi";
function setPm(m) { PM = m; document.querySelectorAll("#pay-modal .seg button").forEach(b => b.className = ""); document.getElementById("pm-" + (m === "netbanking" ? "nb" : m)).className = "on"; }

async function settlePay(stageId, amount) {
  await api("/api/client/payments/pay", { method: "POST", body: { amount, method: PM, stage_id: stageId } });
  document.getElementById("pay-modal").innerHTML = "";
  STATE.overview = await api("/api/client/me");
  toast("Payment successful.");
  render();
}

/* ── Payments & history ── */
async function viewMoney() {
  return `<div class="rise" id="money-root">Loading…</div>`;
}
async function loadMoney() {
  const pays = await api("/api/client/payments");
  const total = STATE.overview.project ? STATE.overview.project.contract_total : 0;
  const paid = pays.filter(p => p.status === "SUCCESS").reduce((s, p) => s + p.amount, 0);
  document.getElementById("money-root").innerHTML = `
    <h2 class="disp" style="font-size:27px;font-weight:600;margin:8px 0">Payments &amp; history</h2>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));margin-top:14px">
      <div class="kpi"><div class="eyebrow">Paid</div><div class="kpi-v" style="color:var(--export)">${inr(paid)}</div></div>
      <div class="kpi"><div class="eyebrow">Contract total</div><div class="kpi-v">${inr(total)}</div></div>
    </div>
    <div class="card wrap" style="margin-top:20px">
      <table class="tbl">
        <thead><tr><th>Date</th><th>Reference</th><th>Method</th><th>Status</th><th class="rt">Amount</th></tr></thead>
        <tbody>${pays.map(p => `<tr><td>${fDate(p.created_at)}</td><td class="mono">${esc(p.txn||"—")}</td><td>${esc(p.method)}</td>
          <td><span class="pill ${p.status==="SUCCESS"?"p-done":"p-due"}">${p.status}</span></td><td class="rt mono">${inr(p.amount)}</td></tr>`).join("") || `<tr><td colspan="5" style="color:var(--mute)">No payments yet.</td></tr>`}</tbody>
      </table>
    </div>`;
}

/* ── Generation ── */
async function viewGen() { return `<div class="rise" id="gen-root">Loading…</div>`; }
async function loadGen() {
  const g = await api("/api/client/generation");
  const recent = g.records.slice(-14);
  const max = Math.max(1, ...recent.map(r => r.kwh));
  const bars = recent.map(r => `<div title="${r.date}: ${r.kwh} kWh" style="flex:1;background:var(--flux);border-radius:2px 2px 0 0;height:${Math.max(4, (r.kwh/max)*140)}px"></div>`).join("");
  document.getElementById("gen-root").innerHTML = `
    <h2 class="disp" style="font-size:27px;font-weight:600;margin:8px 0">Power generation</h2>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin-top:14px">
      <div class="kpi"><div class="eyebrow">This month</div><div class="kpi-v">${g.this_month_kwh} kWh</div></div>
      <div class="kpi"><div class="eyebrow">Lifetime</div><div class="kpi-v">${g.lifetime_kwh} kWh</div></div>
      <div class="kpi"><div class="eyebrow">CO₂ avoided</div><div class="kpi-v" style="color:var(--export)">${g.lifetime_co2_kg} kg</div></div>
    </div>
    <div class="card pad" style="margin-top:20px">
      <div class="eyebrow" style="margin-bottom:12px">Last 14 days</div>
      <div style="display:flex;gap:6px;align-items:flex-end;height:150px">${bars || '<span style="color:var(--mute)">No generation recorded yet.</span>'}</div>
    </div>`;
}

/* ── Services & support ── */
async function viewServices() { return `<div class="rise" id="svc-root">Loading…</div>`; }
async function loadServices() {
  const [catalog, myReqs, tickets] = await Promise.all([
    api("/api/client/services/catalog"), api("/api/client/services/my-requests"), api("/api/client/tickets"),
  ]);
  document.getElementById("svc-root").innerHTML = `
    <h2 class="disp" style="font-size:27px;font-weight:600;margin:8px 0">Services &amp; support</h2>
    <div class="card pad">
      <div class="disp" style="font-weight:600;margin-bottom:10px">Add extra service</div>
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
        ${catalog.map(s => `<div class="card pad" style="background:var(--wafer)">
          <div style="font-weight:600">${esc(s.name)}</div>
          <div style="color:var(--mute);font-size:12.5px;margin:6px 0">${esc(s.description||"")}</div>
          <div class="mono" style="margin-bottom:10px">${s.base_price ? inr(s.base_price) : "Quote on request"}</div>
          <button class="btn sm" onclick="requestService('${s.id}')">Request</button>
        </div>`).join("") || '<span style="color:var(--mute)">No services published yet.</span>'}
      </div>
      ${myReqs.length ? `<div class="wrap" style="margin-top:16px"><table class="tbl"><thead><tr><th>Service</th><th>Status</th><th>Quoted</th></tr></thead>
        <tbody>${myReqs.map(r => `<tr><td>${esc(r.service)}</td><td><span class="pill p-live">${r.status}</span></td><td>${r.quoted_price ? inr(r.quoted_price) : "—"}</td></tr>`).join("")}</tbody></table></div>` : ""}
    </div>
    <div class="card pad" style="margin-top:16px">
      <div class="disp" style="font-weight:600;margin-bottom:10px">Support tickets</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin-bottom:14px">
        <div style="flex:1 1 200px"><label class="lab">Subject</label><input id="tk-subject" class="field" placeholder="What's going on?"></div>
        <button class="btn flux" onclick="createTicket()">Submit</button>
      </div>
      <div class="wrap"><table class="tbl"><thead><tr><th>Subject</th><th>Status</th><th>Opened</th></tr></thead>
        <tbody>${tickets.map(t => `<tr><td>${esc(t.subject)}</td><td><span class="pill p-live">${t.status}</span></td><td>${fDate(t.created_at)}</td></tr>`).join("") || '<tr><td colspan="3" style="color:var(--mute)">No tickets yet.</td></tr>'}</tbody></table></div>
    </div>`;
}
async function requestService(serviceId) {
  await api("/api/client/services/request", { method: "POST", body: { service_id: serviceId } });
  toast("Service requested.");
  loadServices();
}
async function createTicket() {
  const subject = document.getElementById("tk-subject").value.trim();
  if (!subject) return;
  await api("/api/client/tickets", { method: "POST", body: { subject } });
  toast("Ticket submitted.");
  loadServices();
}

function wireTabExtras() {
  if (STATE.tab === "money") loadMoney();
  if (STATE.tab === "gen") loadGen();
  if (STATE.tab === "services") loadServices();
}

boot();
