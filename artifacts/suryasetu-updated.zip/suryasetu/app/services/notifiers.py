"""
Notifier abstraction. Each notifier has a .send(to, subject, body) method.
If the relevant environment variables are not set, a console "mock" provider
is used instead so the whole app works out of the box with zero external
credentials, per spec section 26/51.
"""
import logging

from ..config import settings

logger = logging.getLogger("suryasetu.notifications")
logging.basicConfig(level=logging.INFO)


class EmailNotifier:
    def __init__(self):
        self.configured = bool(settings.smtp_host and settings.smtp_username)

    def send(self, to: str, subject: str, body: str):
        if not self.configured:
            logger.info(f"[MOCK EMAIL] to={to} subject={subject!r} body={body!r}")
            return {"provider": "mock", "to": to, "status": "logged"}
        # Real SMTP send would go here using settings.smtp_* — left as an
        # integration point since no real credentials are provided.
        logger.info(f"[SMTP EMAIL] to={to} subject={subject!r}")
        return {"provider": "smtp", "to": to, "status": "sent"}


class WhatsAppNotifier:
    def __init__(self):
        self.configured = bool(settings.whatsapp_api_url and settings.whatsapp_api_token)

    def send(self, to: str, subject: str, body: str):
        if not self.configured:
            logger.info(f"[MOCK WHATSAPP] to={to} body={body!r}")
            return {"provider": "mock", "to": to, "status": "logged"}
        logger.info(f"[WHATSAPP API] to={to}")
        return {"provider": "whatsapp_api", "to": to, "status": "sent"}


class SMSNotifier:
    def __init__(self):
        self.configured = bool(settings.sms_api_url and settings.sms_api_token)

    def send(self, to: str, subject: str, body: str):
        if not self.configured:
            logger.info(f"[MOCK SMS] to={to} body={body!r}")
            return {"provider": "mock", "to": to, "status": "logged"}
        logger.info(f"[SMS API] to={to}")
        return {"provider": "sms_api", "to": to, "status": "sent"}


email_notifier = EmailNotifier()
whatsapp_notifier = WhatsAppNotifier()
sms_notifier = SMSNotifier()
