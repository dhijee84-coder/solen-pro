from fastapi import APIRouter, Depends, HTTPException, Response, Request
from sqlalchemy.orm import Session

from .. import models, schemas
from ..config import settings
from ..database import get_db
from ..security import create_access_token, verify_password
from ..dependencies import get_current_user
from ..services.audit_service import log_action

router = APIRouter(prefix="/api/auth", tags=["auth"])

# In-memory OTP store for dev: {phone: code}. Fine for a single-process dev server.
_otp_store: dict[str, str] = {}


@router.post("/otp/send")
def send_otp(payload: schemas.OtpSendIn):
    phone = payload.phone.strip()
    if len(phone) != 10 or not phone.isdigit():
        raise HTTPException(400, "Enter a valid 10-digit mobile number.")
    code = settings.dev_otp
    _otp_store[phone] = code
    # In production this would call SMSNotifier; for dev the code is fixed and shown in the UI.
    return {"success": True, "message": f"OTP sent to +91 {phone}. Development OTP is {code}.", "dev_otp": code}


@router.post("/otp/verify")
def verify_otp(payload: schemas.OtpVerifyIn, response: Response, db: Session = Depends(get_db)):
    phone = payload.phone.strip()
    expected = _otp_store.get(phone, settings.dev_otp)
    if payload.code != expected:
        raise HTTPException(400, "That code does not match. Check the SMS and try again.")

    user = db.query(models.User).filter(models.User.phone == phone).first()
    is_new = False
    if not user:
        is_new = True
        user = models.User(
            role=models.RoleName.CLIENT,
            full_name=(payload.full_name or "New Client").strip(),
            phone=phone,
        )
        db.add(user)
        db.flush()
        profile = models.ClientProfile(user_id=user.id)
        db.add(profile)
        db.flush()
        log_action(db, user, "CLIENT_CREATED", entity_type="user", entity_id=user.id)
        db.commit()
        db.refresh(user)

        from ..services import notification_service
        notify_target = db.query(models.ClientProfile).filter(models.ClientProfile.user_id == user.id).first()
        notification_service.notify_new_client(db, notify_target)
        db.commit()

    token = create_access_token(user.id, user.role.value)
    response.set_cookie("access_token", token, httponly=True, samesite="lax", max_age=settings.access_token_expire_minutes * 60)
    return {
        "success": True,
        "is_new_client": is_new,
        "user": {"id": user.id, "name": user.full_name, "phone": user.phone, "role": user.role.value},
    }


@router.post("/admin/login")
def admin_login(payload: schemas.AdminLoginIn, response: Response, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == payload.username).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(401, "Invalid username or password.")
    if user.role == models.RoleName.CLIENT:
        raise HTTPException(403, "Use the client sign-in flow.")
    if not user.is_active:
        raise HTTPException(403, "This account has been deactivated.")

    token = create_access_token(user.id, user.role.value)
    response.set_cookie("access_token", token, httponly=True, samesite="lax", max_age=settings.access_token_expire_minutes * 60)
    log_action(db, user, "LOGIN", entity_type="user", entity_id=user.id)
    db.commit()
    return {"success": True, "user": {"id": user.id, "name": user.full_name, "role": user.role.value}}


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("access_token")
    return {"success": True}


@router.get("/me")
def me(user: models.User = Depends(get_current_user)):
    return {"id": user.id, "name": user.full_name, "role": user.role.value, "phone": user.phone, "email": user.email}
