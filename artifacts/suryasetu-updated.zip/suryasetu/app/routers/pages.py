from fastapi import APIRouter, Request, Depends
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

from .. import models
from ..dependencies import get_optional_user

router = APIRouter(tags=["pages"])
templates = Jinja2Templates(directory="templates")


@router.get("/")
def landing(request: Request):
    return templates.TemplateResponse("public/landing.html", {"request": request})


@router.get("/login")
def client_login_page(request: Request, user: models.User = Depends(get_optional_user)):
    if user and user.role == models.RoleName.CLIENT:
        return RedirectResponse("/client/dashboard")
    return templates.TemplateResponse("auth/login.html", {"request": request})


@router.get("/staff-login")
def staff_login_page(request: Request):
    return templates.TemplateResponse("auth/staff_login.html", {"request": request})


@router.get("/client/dashboard")
def client_dashboard_page(request: Request):
    return templates.TemplateResponse("client/dashboard.html", {"request": request})


@router.get("/admin/dashboard")
def admin_dashboard_page(request: Request):
    return templates.TemplateResponse("admin/console.html", {"request": request, "role": "ADMIN", "role_label": "Admin"})


@router.get("/super-admin/dashboard")
def super_admin_dashboard_page(request: Request):
    return templates.TemplateResponse("admin/console.html", {"request": request, "role": "SUPER_ADMIN", "role_label": "Super Admin"})


@router.get("/primary-admin/dashboard")
def primary_admin_dashboard_page(request: Request):
    return templates.TemplateResponse("admin/console.html", {"request": request, "role": "PRIMARY_ADMIN", "role_label": "Primary Admin"})
