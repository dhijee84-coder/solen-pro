from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..dependencies import require_roles, require_permission
from ..security import hash_password
from ..services import allocation_service, notification_service, project_service, payment_service
from ..services.allocation_service import AllocationError
from ..services.audit_service import log_action

router = APIRouter(prefix="/api/admin", tags=["admin"])

staff_roles = require_roles(models.RoleName.ADMIN, models.RoleName.SUPER_ADMIN, models.RoleName.PRIMARY_ADMIN)
manage_roles = require_roles(models.RoleName.SUPER_ADMIN, models.RoleName.PRIMARY_ADMIN)


# ── dashboard ───────────────────────────────────────────────────────

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    today = datetime.utcnow().date().isoformat()
    total_clients = db.query(models.ClientProfile).count()
    new_today = db.query(models.User).filter(models.User.role == models.RoleName.CLIENT,
                                               models.User.created_at >= datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)).count()
    projects = db.query(models.Project).all()
    active_projects = sum(1 for p in projects if p.status == models.ProjectStatus.ACTIVE)
    near_capacity = sum(1 for p in projects if p.status == models.ProjectStatus.NEAR_CAPACITY)
    full_projects = sum(1 for p in projects if p.status == models.ProjectStatus.FULL)
    panels_available = sum(p.available_panels for p in projects)
    panels_allocated = sum(p.allocated_panels for p in projects)
    pending_payments = db.query(models.Payment).filter(models.Payment.status == models.PaymentStatus.PENDING).count()
    todays_payments = db.query(models.Payment).filter(
        models.Payment.status == models.PaymentStatus.SUCCESS,
        models.Payment.paid_at >= datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0),
    ).count()
    open_tickets = db.query(models.SupportTicket).filter(models.SupportTicket.status.in_(
        [models.TicketStatus.OPEN, models.TicketStatus.ASSIGNED, models.TicketStatus.IN_PROGRESS])).count()
    pending_docs = db.query(models.Document).filter(models.Document.status == models.DocumentStatus.UPLOADED).count()
    pending_services = db.query(models.ClientServiceRequest).filter(models.ClientServiceRequest.status.in_(
        [models.ServiceRequestStatus.REQUESTED, models.ServiceRequestStatus.UNDER_REVIEW])).count()

    recent_audit = db.query(models.AuditLog).order_by(models.AuditLog.timestamp.desc()).limit(15).all()

    return {
        "cards": {
            "total_clients": total_clients, "new_clients_today": new_today,
            "active_projects": active_projects, "projects_near_capacity": near_capacity,
            "projects_full": full_projects, "panels_available": panels_available,
            "panels_allocated": panels_allocated, "pending_payments": pending_payments,
            "todays_payments": todays_payments, "open_tickets": open_tickets,
            "pending_documents": pending_docs, "pending_service_requests": pending_services,
        },
        "recent_activity": [{
            "action": a.action, "entity_type": a.entity_type, "entity_id": a.entity_id,
            "timestamp": a.timestamp.isoformat(),
        } for a in recent_audit],
    }


# ── clients ─────────────────────────────────────────────────────────

def _client_summary(c: models.ClientProfile):
    cp = c.client_project
    last_payment = sorted(c.payments, key=lambda p: p.created_at, reverse=True)[:1]
    return {
        "id": c.id, "name": c.user.full_name, "phone": c.user.phone, "email": c.user.email,
        "registered_at": c.created_at.isoformat(), "kyc_status": c.kyc_status,
        "onboarding_stage": c.onboarding_stage,
        "project": cp.project.project_name if cp else None,
        "panels": cp.allocated_panel_count if cp else 0,
        "payment_status": last_payment[0].status.value if last_payment else "NONE",
        "is_active": c.user.is_active,
    }


@router.get("/clients")
def list_clients(q: str = "", db: Session = Depends(get_db), user: models.User = Depends(require_permission("clients.view"))):
    query = db.query(models.ClientProfile).join(models.User, models.ClientProfile.user_id == models.User.id)
    if q:
        like = f"%{q}%"
        query = query.filter(
            (models.User.full_name.ilike(like)) | (models.User.phone.ilike(like)) |
            (models.User.email.ilike(like)) | (models.ClientProfile.id.ilike(like))
        )
    clients = query.order_by(models.ClientProfile.created_at.desc()).all()
    return [_client_summary(c) for c in clients]


@router.get("/clients/{client_id}")
def client_detail(client_id: str, db: Session = Depends(get_db), user: models.User = Depends(require_permission("clients.view"))):
    c = db.query(models.ClientProfile).filter(models.ClientProfile.id == client_id).first()
    if not c:
        raise HTTPException(404, "Client not found.")
    stages = db.query(models.ProjectStage).filter(models.ProjectStage.client_id == c.id).order_by(models.ProjectStage.stage_number).all()
    docs = db.query(models.Document).filter(models.Document.client_id == c.id).all()
    pays = db.query(models.Payment).filter(models.Payment.client_id == c.id).order_by(models.Payment.created_at.desc()).all()
    tickets = db.query(models.SupportTicket).filter(models.SupportTicket.client_id == c.id).all()
    services = db.query(models.ClientServiceRequest).filter(models.ClientServiceRequest.client_id == c.id).all()
    panels = db.query(models.Panel).filter(models.Panel.client_id == c.id).all()

    return {
        "profile": {
            "id": c.id, "name": c.user.full_name, "phone": c.user.phone, "email": c.user.email,
            "address": c.address, "city": c.city, "state": c.state, "pincode": c.pincode,
            "kyc_status": c.kyc_status, "pan_number": c.pan_number, "aadhaar_masked": c.aadhaar_masked,
            "onboarding_stage": c.onboarding_stage, "admin_notes": c.admin_notes,
            "assigned_admin_id": c.assigned_admin_id,
            "visibility": {k: getattr(c, k) for k in [
                "show_generation", "show_payments", "show_project", "show_panels",
                "show_documents", "show_services", "show_support", "show_notifications"]},
        },
        "electricity": None if not c.electricity_connection else {
            "rr_number": c.electricity_connection.rr_number, "discom": c.electricity_connection.discom,
            "avg_monthly_units": c.electricity_connection.avg_monthly_units,
            "proposed_kw": c.electricity_connection.proposed_kw,
            "system_cost": c.electricity_connection.system_cost,
            "payable_amount": c.electricity_connection.payable_amount,
        },
        "project": None if not c.client_project else {
            "project_name": c.client_project.project.project_name,
            "project_code": c.client_project.project.project_code,
            "allocated_panels": c.client_project.allocated_panel_count,
            "allocated_capacity_kw": c.client_project.allocated_capacity_kw,
        },
        "panels": [{"id": p.id, "serial_number": p.serial_number, "status": p.status.value} for p in panels],
        "stages": [{
            "id": s.id, "number": s.stage_number, "name": s.stage_name, "status": s.status.value,
            "percentage": s.percentage, "payment_status": s.payment_status,
        } for s in stages],
        "documents": [{"id": d.id, "type": d.document_type.value, "status": d.status.value, "filename": d.original_filename} for d in docs],
        "payments": [{"id": p.id, "amount": p.amount, "status": p.status.value, "method": p.payment_method, "created_at": p.created_at.isoformat()} for p in pays],
        "tickets": [{"id": t.id, "subject": t.subject, "status": t.status.value} for t in tickets],
        "service_requests": [{"id": s.id, "service": s.service.name, "status": s.status.value} for s in services],
    }


@router.put("/clients/{client_id}")
def update_client(client_id: str, payload: dict, db: Session = Depends(get_db), user: models.User = Depends(require_permission("clients.edit"))):
    c = db.query(models.ClientProfile).filter(models.ClientProfile.id == client_id).first()
    if not c:
        raise HTTPException(404, "Client not found.")
    editable = ["address", "city", "state", "pincode", "admin_notes", "assigned_admin_id"]
    old = {f: getattr(c, f) for f in editable}
    for f in editable:
        if f in payload:
            setattr(c, f, payload[f])
    visibility_fields = ["show_generation", "show_payments", "show_project", "show_panels",
                          "show_documents", "show_services", "show_support", "show_notifications"]
    for f in visibility_fields:
        if f in payload:
            setattr(c, f, bool(payload[f]))
    log_action(db, user, "CLIENT_UPDATED", entity_type="client", entity_id=c.id, old_value=str(old), new_value=str(payload))
    db.commit()
    return {"success": True}


@router.post("/clients/{client_id}/verify-document/{document_id}")
def verify_document(client_id: str, document_id: str, approve: bool = True, db: Session = Depends(get_db),
                     user: models.User = Depends(require_permission("documents.view"))):
    doc = db.query(models.Document).filter(models.Document.id == document_id, models.Document.client_id == client_id).first()
    if not doc:
        raise HTTPException(404, "Document not found.")
    doc.status = models.DocumentStatus.VERIFIED if approve else models.DocumentStatus.REJECTED
    doc.verified_by = user.id
    doc.verified_at = datetime.utcnow()
    log_action(db, user, "DOCUMENT_VERIFIED", entity_type="document", entity_id=doc.id, new_value=doc.status.value)
    db.commit()
    return {"success": True, "status": doc.status.value}


# ── projects ────────────────────────────────────────────────────────

def _project_dict(p: models.Project):
    return {
        "id": p.id, "code": p.project_code, "name": p.project_name, "site_name": p.site_name,
        "location": p.location, "capacity_kw": p.capacity_kw, "total_panels": p.total_panels,
        "allocated_panels": p.allocated_panels, "available_panels": p.available_panels,
        "utilization": round(p.utilization * 100, 1), "status": p.status.value,
    }


@router.get("/projects")
def list_projects(db: Session = Depends(get_db), user: models.User = Depends(require_permission("projects.view"))):
    return [_project_dict(p) for p in db.query(models.Project).order_by(models.Project.created_at.desc()).all()]


@router.post("/projects")
def create_project(payload: schemas.ProjectCreateIn, db: Session = Depends(get_db), user: models.User = Depends(require_permission("projects.create"))):
    if db.query(models.Project).filter(models.Project.project_code == payload.project_code).first():
        raise HTTPException(400, "Project code already exists.")
    p = models.Project(**payload.model_dump(), status=models.ProjectStatus.PLANNING)
    db.add(p)
    db.flush()
    log_action(db, user, "PROJECT_CREATED", entity_type="project", entity_id=p.id, new_value=p.project_name)
    db.commit()
    return _project_dict(p)


@router.put("/projects/{project_id}")
def update_project(project_id: str, payload: dict, db: Session = Depends(get_db), user: models.User = Depends(require_permission("projects.edit"))):
    p = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not p:
        raise HTTPException(404, "Project not found.")
    for f in ["project_name", "site_name", "location", "address", "commissioning_date"]:
        if f in payload:
            setattr(p, f, payload[f])
    if "status" in payload and payload["status"] in models.ProjectStatus.__members__:
        p.status = models.ProjectStatus[payload["status"]]
    log_action(db, user, "PROJECT_UPDATED", entity_type="project", entity_id=p.id, new_value=str(payload))
    db.commit()
    return _project_dict(p)


@router.post("/projects/{project_id}/panels")
def add_panels(project_id: str, payload: schemas.PanelBulkAddIn, db: Session = Depends(get_db),
               user: models.User = Depends(require_permission("panels.create"))):
    p = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not p:
        raise HTTPException(404, "Project not found.")
    max_seq = db.query(models.Panel).filter(models.Panel.project_id == project_id).count()
    existing_serials = db.query(models.Panel).filter(models.Panel.project_id == project_id).count()
    created = []
    for i in range(payload.count):
        seq = max_seq + i + 1
        serial = f"{p.project_code}-P{existing_serials + i + 1:05d}"
        panel = models.Panel(
            serial_number=serial, project_id=project_id, manufacturer=payload.manufacturer,
            model=payload.model, watt_rating=payload.watt_rating, added_sequence=seq,
            status=models.PanelStatus.AVAILABLE,
        )
        db.add(panel)
        created.append(serial)
    p.total_panels += payload.count
    p.capacity_kw += payload.count * payload.watt_rating / 1000.0
    if p.status == models.ProjectStatus.PLANNING:
        p.status = models.ProjectStatus.ACTIVE
    log_action(db, user, "PROJECT_UPDATED", entity_type="project", entity_id=p.id, new_value=f"+{payload.count} panels")
    db.commit()
    return {"success": True, "added": len(created), "first_serial": created[0] if created else None, "last_serial": created[-1] if created else None}


@router.get("/panels")
def list_panels(project_id: str = None, status: str = None, db: Session = Depends(get_db),
                 user: models.User = Depends(require_permission("panels.view"))):
    q = db.query(models.Panel)
    if project_id:
        q = q.filter(models.Panel.project_id == project_id)
    if status:
        q = q.filter(models.Panel.status == status)
    panels = q.order_by(models.Panel.added_sequence).limit(500).all()
    return [{
        "id": x.id, "serial_number": x.serial_number, "project_id": x.project_id,
        "status": x.status.value, "client_id": x.client_id, "watt_rating": x.watt_rating,
        "added_sequence": x.added_sequence,
    } for x in panels]


@router.post("/allocate")
def allocate(payload: schemas.AllocateIn, db: Session = Depends(get_db), user: models.User = Depends(require_permission("panels.allocate"))):
    try:
        panels = allocation_service.allocate_panels(db, payload.project_id, payload.client_id, payload.panel_count, user)
    except AllocationError as e:
        raise HTTPException(400, str(e))
    return {
        "success": True,
        "allocated_serials": [p.serial_number for p in panels],
        "count": len(panels),
    }


@router.get("/allocate/preview")
def allocate_preview(project_id: str, count: int, db: Session = Depends(get_db), user: models.User = Depends(require_permission("panels.allocate"))):
    """FIFO preview shown to the admin before confirming (spec section 47)."""
    candidates = (
        db.query(models.Panel)
        .filter(models.Panel.project_id == project_id, models.Panel.status == models.PanelStatus.AVAILABLE)
        .order_by(models.Panel.added_sequence.asc())
        .limit(count)
        .all()
    )
    return {
        "requested": count, "available_shown": len(candidates),
        "serials": [p.serial_number for p in candidates],
        "sufficient": len(candidates) >= count,
    }


@router.post("/panels/{panel_id}/deallocate")
def deallocate(panel_id: str, db: Session = Depends(get_db), user: models.User = Depends(require_permission("panels.allocate"))):
    try:
        panel = allocation_service.deallocate_panel(db, panel_id, user)
    except AllocationError as e:
        raise HTTPException(400, str(e))
    return {"success": True, "panel_id": panel.id}


@router.post("/clients/{client_id}/assign-project")
def assign_project_and_provision(client_id: str, project_id: str, panel_count: int,
                                  db: Session = Depends(get_db), user: models.User = Depends(require_permission("panels.allocate"))):
    """Convenience endpoint: allocate panels, create the six stages, and backfill generation history."""
    try:
        allocation_service.allocate_panels(db, project_id, client_id, panel_count, user)
    except AllocationError as e:
        raise HTTPException(400, str(e))
    project_service.create_stages_for_client(db, client_id)
    client = db.query(models.ClientProfile).filter(models.ClientProfile.id == client_id).first()
    kw = client.electricity_connection.proposed_kw if client.electricity_connection else panel_count * 0.4
    project_service.simulate_generation_history(db, project_id, client_id, kw)
    return {"success": True}


# ── stages ──────────────────────────────────────────────────────────

@router.put("/stages/{stage_id}")
def update_stage(stage_id: str, payload: schemas.StageUpdateIn, db: Session = Depends(get_db),
                  user: models.User = Depends(require_permission("clients.edit"))):
    s = db.query(models.ProjectStage).filter(models.ProjectStage.id == stage_id).first()
    if not s:
        raise HTTPException(404, "Stage not found.")
    if payload.status not in models.StageStatus.__members__:
        raise HTTPException(400, "Invalid stage status.")
    old_status = s.status.value
    s.status = models.StageStatus[payload.status]
    if payload.notes is not None:
        s.notes = payload.notes
    if s.status == models.StageStatus.COMPLETED and not s.completed_at:
        s.completed_at = datetime.utcnow()
        s.completed_by = user.id
    if s.status == models.StageStatus.PAYMENT_DUE:
        s.payment_status = "DUE"
    log_action(db, user, "STAGE_UPDATED", entity_type="stage", entity_id=s.id, old_value=old_status, new_value=s.status.value)
    db.commit()
    return {"success": True}


# ── payments ────────────────────────────────────────────────────────

@router.get("/payments")
def list_all_payments(status: str = None, db: Session = Depends(get_db), user: models.User = Depends(require_permission("payments.view"))):
    q = db.query(models.Payment)
    if status:
        q = q.filter(models.Payment.status == status)
    pays = q.order_by(models.Payment.created_at.desc()).limit(200).all()
    return [{
        "id": p.id, "client_id": p.client_id, "client_name": p.client.user.full_name,
        "amount": p.amount, "status": p.status.value, "method": p.payment_method,
        "created_at": p.created_at.isoformat(), "is_first_payment": p.is_first_payment,
    } for p in pays]


@router.post("/clients/{client_id}/payments")
def record_payment_for_client(client_id: str, payload: schemas.PaymentIn, db: Session = Depends(get_db),
                               user: models.User = Depends(require_permission("payments.create"))):
    c = db.query(models.ClientProfile).filter(models.ClientProfile.id == client_id).first()
    if not c:
        raise HTTPException(404, "Client not found.")
    payment = payment_service.record_payment(db, c, payload.amount, payload.method, user, stage_id=payload.stage_id, service_id=payload.service_id)
    return {"success": True, "payment_id": payment.id, "txn": payment.transaction_reference}


# ── services & tickets ─────────────────────────────────────────────

@router.get("/services")
def list_services(db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    return [{"id": s.id, "name": s.name, "description": s.description, "base_price": s.base_price, "is_active": s.is_active}
            for s in db.query(models.Service).all()]


@router.post("/services")
def create_service(payload: schemas.ServiceCreateIn, db: Session = Depends(get_db), user: models.User = Depends(require_permission("clients.services.manage"))):
    s = models.Service(**payload.model_dump())
    db.add(s)
    log_action(db, user, "SERVICE_CREATED", entity_type="service", entity_id=s.name, new_value=payload.name)
    db.commit()
    return {"success": True, "id": s.id}


@router.get("/service-requests")
def list_service_requests(status: str = None, db: Session = Depends(get_db), user: models.User = Depends(require_permission("clients.services.view"))):
    q = db.query(models.ClientServiceRequest)
    if status:
        q = q.filter(models.ClientServiceRequest.status == status)
    reqs = q.order_by(models.ClientServiceRequest.created_at.desc()).all()
    return [{
        "id": r.id, "client_id": r.client_id, "client_name": r.client.user.full_name,
        "service": r.service.name, "status": r.status.value, "quoted_price": r.quoted_price,
        "created_at": r.created_at.isoformat(),
    } for r in reqs]


@router.put("/service-requests/{request_id}")
def update_service_request(request_id: str, payload: schemas.ServiceRequestUpdateIn, db: Session = Depends(get_db),
                            user: models.User = Depends(require_permission("clients.services.manage"))):
    r = db.query(models.ClientServiceRequest).filter(models.ClientServiceRequest.id == request_id).first()
    if not r:
        raise HTTPException(404, "Service request not found.")
    if payload.status not in models.ServiceRequestStatus.__members__:
        raise HTTPException(400, "Invalid status.")
    r.status = models.ServiceRequestStatus[payload.status]
    if payload.quoted_price is not None:
        r.quoted_price = payload.quoted_price
    if payload.notes is not None:
        r.notes = payload.notes
    r.assigned_admin_id = user.id
    log_action(db, user, "SERVICE_REQUESTED", entity_type="service_request", entity_id=r.id, new_value=r.status.value)
    db.commit()
    return {"success": True}


@router.get("/tickets")
def list_tickets(status: str = None, db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    q = db.query(models.SupportTicket)
    if status:
        q = q.filter(models.SupportTicket.status == status)
    ts = q.order_by(models.SupportTicket.created_at.desc()).all()
    return [{
        "id": t.id, "client_id": t.client_id, "client_name": t.client.user.full_name,
        "subject": t.subject, "status": t.status.value, "priority": t.priority,
        "created_at": t.created_at.isoformat(),
    } for t in ts]


@router.put("/tickets/{ticket_id}")
def update_ticket(ticket_id: str, payload: dict, db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    t = db.query(models.SupportTicket).filter(models.SupportTicket.id == ticket_id).first()
    if not t:
        raise HTTPException(404, "Ticket not found.")
    if "status" in payload and payload["status"] in models.TicketStatus.__members__:
        t.status = models.TicketStatus[payload["status"]]
    if "assigned_admin_id" in payload:
        t.assigned_admin_id = payload["assigned_admin_id"]
    db.commit()
    return {"success": True}


# ── documents (admin-wide) ────────────────────────────────────────

@router.get("/documents")
def list_all_documents(status: str = None, db: Session = Depends(get_db), user: models.User = Depends(require_permission("documents.view"))):
    q = db.query(models.Document)
    if status:
        q = q.filter(models.Document.status == status)
    docs = q.order_by(models.Document.uploaded_at.desc()).limit(200).all()
    return [{
        "id": d.id, "client_id": d.client_id, "client_name": d.client.user.full_name,
        "type": d.document_type.value, "status": d.status.value, "filename": d.original_filename,
        "uploaded_at": d.uploaded_at.isoformat(),
    } for d in docs]


# ── notifications ───────────────────────────────────────────────────

@router.get("/notifications")
def my_notifications(db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    ns = db.query(models.Notification).filter(models.Notification.recipient_user_id == user.id).order_by(models.Notification.created_at.desc()).limit(80).all()
    return [{
        "id": n.id, "type": n.type, "title": n.title, "message": n.message,
        "priority": n.priority, "is_read": n.is_read, "created_at": n.created_at.isoformat(),
        "related_entity": n.related_entity, "related_entity_id": n.related_entity_id,
    } for n in ns]


@router.post("/notifications/{notification_id}/read")
def mark_notification_read(notification_id: str, db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    n = db.query(models.Notification).filter(models.Notification.id == notification_id, models.Notification.recipient_user_id == user.id).first()
    if not n:
        raise HTTPException(404, "Notification not found.")
    n.is_read = True
    db.commit()
    return {"success": True}


@router.get("/notification-contacts")
def list_contacts(db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    cs = db.query(models.NotificationContact).filter(models.NotificationContact.user_id == user.id).all()
    return [{"id": c.id, "type": c.type.value, "value": c.value, "label": c.label, "is_active": c.is_active} for c in cs]


@router.post("/notification-contacts")
def add_contact(payload: schemas.ContactAddIn, db: Session = Depends(get_db), user: models.User = Depends(staff_roles)):
    if payload.type not in models.ContactType.__members__:
        raise HTTPException(400, "Invalid contact type.")
    c = models.NotificationContact(user_id=user.id, type=models.ContactType[payload.type], value=payload.value, label=payload.label)
    db.add(c)
    db.commit()
    return {"success": True, "id": c.id}


# ── admin management (Super Admin + Primary Admin only) ─────────────

@router.get("/staff")
def list_staff(db: Session = Depends(get_db), user: models.User = Depends(manage_roles)):
    staff = db.query(models.User).filter(models.User.role.in_([models.RoleName.ADMIN, models.RoleName.SUPER_ADMIN])).all()
    return [{"id": s.id, "name": s.full_name, "username": s.username, "role": s.role.value, "is_active": s.is_active} for s in staff]


@router.post("/staff")
def create_staff(payload: schemas.AdminCreateIn, db: Session = Depends(get_db), user: models.User = Depends(manage_roles)):
    if payload.role not in ("ADMIN", "SUPER_ADMIN"):
        raise HTTPException(400, "Role must be ADMIN or SUPER_ADMIN.")
    if payload.role == "SUPER_ADMIN" and user.role != models.RoleName.PRIMARY_ADMIN:
        raise HTTPException(403, "Only the Primary Admin can create Super Admins.")
    if db.query(models.User).filter(models.User.username == payload.username).first():
        raise HTTPException(400, "Username already taken.")
    s = models.User(
        role=models.RoleName[payload.role], full_name=payload.full_name, username=payload.username,
        email=payload.email, hashed_password=hash_password(payload.password), created_by=user.id,
    )
    db.add(s)
    db.flush()
    log_action(db, user, "ADMIN_CREATED" if payload.role == "ADMIN" else "ROLE_CHANGED", entity_type="user", entity_id=s.id, new_value=payload.role)
    db.commit()
    return {"success": True, "id": s.id}


@router.put("/staff/{staff_id}")
def update_staff(staff_id: str, payload: dict, db: Session = Depends(get_db), user: models.User = Depends(manage_roles)):
    s = db.query(models.User).filter(models.User.id == staff_id).first()
    if not s or s.role not in (models.RoleName.ADMIN, models.RoleName.SUPER_ADMIN):
        raise HTTPException(404, "Staff member not found.")
    if s.role == models.RoleName.SUPER_ADMIN and user.role != models.RoleName.PRIMARY_ADMIN:
        raise HTTPException(403, "Only the Primary Admin can modify Super Admins.")
    if "full_name" in payload:
        s.full_name = payload["full_name"]
    if "is_active" in payload:
        s.is_active = bool(payload["is_active"])
    log_action(db, user, "ADMIN_EDITED" if s.role == models.RoleName.ADMIN else "ROLE_CHANGED",
               entity_type="user", entity_id=s.id, new_value=str(payload))
    db.commit()
    return {"success": True}


@router.delete("/staff/{staff_id}")
def remove_staff(staff_id: str, db: Session = Depends(get_db), user: models.User = Depends(manage_roles)):
    s = db.query(models.User).filter(models.User.id == staff_id).first()
    if not s or s.role not in (models.RoleName.ADMIN, models.RoleName.SUPER_ADMIN):
        raise HTTPException(404, "Staff member not found.")
    if s.role == models.RoleName.SUPER_ADMIN and user.role != models.RoleName.PRIMARY_ADMIN:
        raise HTTPException(403, "Only the Primary Admin can remove Super Admins.")
    s.is_active = False
    log_action(db, user, "ADMIN_REMOVED" if s.role == models.RoleName.ADMIN else "ROLE_CHANGED",
               entity_type="user", entity_id=s.id, new_value="deactivated")
    db.commit()
    return {"success": True}


# ── reports ─────────────────────────────────────────────────────────

@router.get("/reports/summary")
def reports_summary(db: Session = Depends(get_db), user: models.User = Depends(require_permission("reports.view"))):
    total_revenue = db.query(models.Payment).filter(models.Payment.status == models.PaymentStatus.SUCCESS).all()
    revenue_sum = sum(p.amount for p in total_revenue)
    projects = db.query(models.Project).all()
    return {
        "total_revenue": revenue_sum,
        "total_payments": len(total_revenue),
        "total_clients": db.query(models.ClientProfile).count(),
        "project_utilization": [{"project": p.project_name, "utilization_pct": round(p.utilization * 100, 1)} for p in projects],
    }


# ── audit log ───────────────────────────────────────────────────────

@router.get("/audit-logs")
def audit_logs(db: Session = Depends(get_db), user: models.User = Depends(require_permission("audit_logs.view"))):
    logs = db.query(models.AuditLog).order_by(models.AuditLog.timestamp.desc()).limit(300).all()
    return [{
        "id": a.id, "actor_user_id": a.actor_user_id, "action": a.action,
        "entity_type": a.entity_type, "entity_id": a.entity_id,
        "new_value": a.new_value, "timestamp": a.timestamp.isoformat(),
    } for a in logs]
