import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    secret_key: str = "change-this-in-production-please"
    database_url: str = "sqlite:///./suryasetu.db"
    access_token_expire_minutes: int = 480
    algorithm: str = "HS256"

    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from: str = "notifications@suryasetu.local"

    whatsapp_api_url: str = ""
    whatsapp_api_token: str = ""

    sms_api_url: str = ""
    sms_api_token: str = ""
    dev_otp: str = "1234"

    upload_dir: str = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")

    # Capacity alert thresholds (fraction of total panels allocated)
    capacity_warning_threshold: float = 0.80
    capacity_critical_threshold: float = 0.90

    class Config:
        env_file = ".env"


settings = Settings()
os.makedirs(settings.upload_dir, exist_ok=True)
