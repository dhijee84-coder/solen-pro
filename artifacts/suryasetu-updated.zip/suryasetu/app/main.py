from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .database import Base, engine
from .routers import auth, client, admin, primary_admin, pages

Base.metadata.create_all(bind=engine)

app = FastAPI(title="SuryaSetu", description="Solar energy subscription / panel allocation management platform")

app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

app.include_router(pages.router)
app.include_router(auth.router)
app.include_router(client.router)
app.include_router(admin.router)
app.include_router(primary_admin.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "suryasetu"}
