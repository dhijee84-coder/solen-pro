from .models import RoleName

ALL_PERMISSIONS = [
    "users.view", "users.create", "users.edit", "users.delete",
    "admins.create", "admins.edit", "admins.remove",
    "super_admins.create", "super_admins.edit", "super_admins.remove",
    "clients.view", "clients.create", "clients.edit", "clients.delete",
    "clients.services.view", "clients.services.manage",
    "projects.view", "projects.create", "projects.edit", "projects.delete",
    "panels.view", "panels.create", "panels.edit", "panels.allocate",
    "payments.view", "payments.create", "payments.edit",
    "documents.view", "documents.upload", "documents.delete",
    "notifications.view", "notifications.create",
    "reports.view",
    "audit_logs.view",
    "system.settings",
]

# Role -> permission codes. PRIMARY_ADMIN implicitly has everything (checked in code),
# but we also list it explicitly here so the seeded role_permissions table is complete.
ROLE_PERMISSIONS = {
    RoleName.PRIMARY_ADMIN: ALL_PERMISSIONS,
    RoleName.SUPER_ADMIN: [
        "clients.view", "clients.create", "clients.edit", "clients.delete",
        "clients.services.view", "clients.services.manage",
        "admins.create", "admins.edit", "admins.remove",
        "projects.view", "projects.create", "projects.edit", "projects.delete",
        "panels.view", "panels.create", "panels.edit", "panels.allocate",
        "payments.view", "payments.create", "payments.edit",
        "documents.view", "documents.upload", "documents.delete",
        "notifications.view", "notifications.create",
        "reports.view", "audit_logs.view",
        "users.view",
    ],
    RoleName.ADMIN: [
        "clients.view", "clients.create", "clients.edit",
        "clients.services.view", "clients.services.manage",
        "projects.view",
        "panels.view", "panels.allocate",
        "payments.view", "payments.create", "payments.edit",
        "documents.view", "documents.upload",
        "notifications.view", "notifications.create",
        "reports.view",
    ],
    RoleName.CLIENT: [],
}


def role_has_permission(role: RoleName, code: str) -> bool:
    if role == RoleName.PRIMARY_ADMIN:
        return True
    return code in ROLE_PERMISSIONS.get(role, [])
