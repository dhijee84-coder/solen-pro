"""Warranty status calculation and claim workflow helpers."""
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from .. import models
from ..config import settings
from .audit_service import log_action
from . import notification_service


def get_expiring_days(db: Session) -> int:
    row = db.query(models.SystemSetting).filter(models.SystemSetting.key == "warranty_expiring_days").first()
    if row and row.value.isdigit():
        return int(row.value)
    return 90


def panel_warranty_status(panel: models.Panel, expiring_days: int = 90) -> str:
    return panel.computed_warranty_status(expiring_days)


def ensure_panel_warranty_dates(panel: models.Panel, install_date: str | None = None):
    """Set warranty start/end from installation date + warranty_years if missing."""
    if not panel.warranty_start_date:
        panel.warranty_start_date = install_date or panel.installation_date or datetime.utcnow().strftime("%Y-%m-%d")
    if not panel.warranty_end_date and panel.warranty_years:
        try:
            start = datetime.strptime(panel.warranty_start_date[:10], "%Y-%m-%d")
            end = start + timedelta(days=365 * panel.warranty_years)
            panel.warranty_end_date = end.strftime("%Y-%m-%d")
        except Exception:
            pass
    if not panel.warranty_provider:
        panel.warranty_provider = panel.manufacturer or "Manufacturer"
    if not panel.warranty_type:
        panel.warranty_type = "MANUFACTURER"


def create_claim(
    db: Session,
    panel: models.Panel,
    client: models.ClientProfile,
    issue_summary: str,
    description: str = "",
    date_discovered: str | None = None,
    contact_phone: str = "",
    contact_email: str = "",
) -> models.WarrantyClaim:
    claim = models.WarrantyClaim(
        panel_id=panel.id,
        client_id=client.id,
        issue_summary=issue_summary,
        description=description,
        date_discovered=date_discovered,
        contact_phone=contact_phone,
        contact_email=contact_email,
        status=models.WarrantyClaimStatus.SUBMITTED,
    )
    db.add(claim)
    db.flush()
    log_action(db, client.user, "WARRANTY_CLAIM_SUBMITTED", entity_type="warranty_claim", entity_id=claim.id)
    # Notify staff
    try:
        notification_service.notify_service_request(db, claim)  # reuse routing pattern
    except Exception:
        pass
    return claim


def update_claim_status(
    db: Session,
    claim: models.WarrantyClaim,
    new_status: models.WarrantyClaimStatus,
    actor: models.User,
    notes: str = "",
):
    old = claim.status.value if claim.status else ""
    claim.status = new_status
    if notes:
        claim.resolution_notes = (claim.resolution_notes or "") + f"\n[{datetime.utcnow().isoformat()}] {notes}"
    claim.updated_at = datetime.utcnow()
    log_action(
        db, actor, "WARRANTY_CLAIM_UPDATED",
        entity_type="warranty_claim", entity_id=claim.id,
        old_value=old, new_value=new_status.value,
    )
    # Notify client
    if claim.client and claim.client.user:
        db.add(models.Notification(
            recipient_user_id=claim.client.user_id,
            type="WARRANTY",
            title=f"Warranty claim {new_status.value}",
            message=f"Your warranty claim for panel has been updated to {new_status.value}.",
            priority="NORMAL",
            related_entity="warranty_claim",
            related_entity_id=claim.id,
        ))
